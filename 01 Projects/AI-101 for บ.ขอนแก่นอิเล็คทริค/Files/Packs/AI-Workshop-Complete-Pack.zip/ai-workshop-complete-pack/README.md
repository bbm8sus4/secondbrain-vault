# AI Workshop Complete Pack

รวมไฟล์ทั้งหมดที่เกี่ยวกับ AI Workshop — บ.ขอนแก่นอิเล็คทริค จาก workspace นี้

## โฟลเดอร์หลัก

- `secondbrain-vault-project/` — โปรเจกต์จาก Obsidian vault ล่าสุด
- `original-upload-extracted/` — ไฟล์ที่แตกจาก zip เดิมที่อัปโหลดเข้ามา
- `presentation-pack/` — ชุดที่คัดไว้สำหรับเปิดสอนจริง
- `handouts/` — handout / prompt pack / offline pack
- `agent-outputs/` — output จาก kkai agents เช่น agenda, scope, lab, QA, runbook
- `uploads/` — zip ต้นฉบับที่ผู้ใช้อัปโหลด

## เริ่มจากไฟล์ไหน

- เปิดสอนจริง: `presentation-pack/slides/*.pdf`
- ตารางสอน: `agent-outputs/agenda-minute-by-minute.md`
- Runbook วันจริง: `agent-outputs/dayof-runbook.md`
- สถานะรวม: `agent-outputs/pm-status.md`
- Lab/prompt: `agent-outputs/lab-exercises-and-prompts.md`

## ลิงก์หลัก

- Learner dashboard: https://khonkaen-workshop-learner.pages.dev
- Full dashboard: https://khonkaen-ai-workshop.pages.dev
