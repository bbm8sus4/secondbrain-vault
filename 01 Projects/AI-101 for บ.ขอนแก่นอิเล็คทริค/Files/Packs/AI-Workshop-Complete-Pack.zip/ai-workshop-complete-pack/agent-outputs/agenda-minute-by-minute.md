---
title: agenda-minute-by-minute — AI Workshop บ.ขอนแก่นอิเล็คทริค
owner_agent: kkai-curriculum
based_on: Outline-Cowork-ClaudeCode-Warp + scope-core-advanced-demo.md (ยืนยันแล้ว) + research-learner-profile
date: 2026-07-07
status: FINAL
duration: 1 วัน (09:00–16:30)
learners: 15 ท่าน — ตอบสำรวจ 11, 9/11 สายการตลาด, มั่นใจเฉลี่ย 2.7/5 (ระดับเริ่มต้น)
main_link: https://khonkaen-workshop-learner.pages.dev (learner 2-tab เท่านั้น)
slide_mapping: Part1=พื้นฐาน Claude · Part2=AI การตลาด · Part3=Landing Page · Part4=Cowork+Claude Code+Warp (รวมก้อนเดียว) — ตรงกับ deck จริง
---

# กำหนดการนาทีต่อนาที — AI Workshop (ขอนแก่นอิเล็คทริค)

> **Scope 3 ชั้น (ยืนยันแล้ว)**
> - **Core** — ทุกคน, **browser-only เท่านั้น**: Claude (หน้าเว็บ) + งานจริง + landing template ผ่านเบราว์เซอร์
> - **Advanced** — เฉพาะคนพร้อม + buddy: GitHub + deploy + database **ทำจริง**
> - **Demo-only** — วิทยากรฉายจอด้วย **บัญชี demo** สำหรับหัวข้อเสี่ยง/เกินเวลา (ผู้เรียนดู ไม่ต้องทำตาม)
>
> **หลักการวางเวลา**
> - ผู้เรียนส่วนใหญ่สายการตลาด มั่นใจ 2.7/5 → **น้ำหนักอยู่ที่ Core** (~75% ของวันอยู่บนเบราว์เซอร์ล้วน)
> - เลกเชอร์บล็อกละ **ไม่เกิน 15 นาที** แล้วลงมือทันที (บรรยาย:ลงมือ ≈ 25:75)
> - แต่ละ **Part สไลด์มีสล็อตเวลาชัดเจน ไม่ทับกัน** (ดูคอลัมน์ Part)
> - Link เดียวที่ผู้เรียนใช้: **https://khonkaen-workshop-learner.pages.dev** (2-tab) · 3-tab เฉพาะ PM/เจ้าของ/วิทยากร
> - **Advanced = stretch block คู่ buddy** สำหรับ 3 คนพร้อม (เบนซ์ 95 / ต่อ 88 / นัท 80 — เบนซ์นำสายเทคนิค) · **Demo-only = แทรกสั้น ๆ ตอนหัวข้อเสี่ยง/เกินเวลา ฉายด้วยบัญชี demo** (ไม่ใช่หัวข้อตายตัว)
> - **buddy:** 1 คนพร้อม + 1–2 คนเริ่มต้น (≈3 คน/บัญชี Claude) — คนเก่งช่วยคนช้า
> - **Fallback เน็ตล่ม:** สลับเป็น demo บนจอ (บัญชี demo) + **`lab-offline-pack.pdf`** (A4 5 หน้า มี prompt Core 6 + Advanced + เว็บสำรอง) + buddy ทันที
> - **แหล่ง prompt/exercise ทุกช่วง hands-on:** `lab-exercises-and-prompts.md` (2 ระดับ Core/Advanced) · fallback = `lab-offline-pack.pdf`
> - **ห้าม:** rebuild/clear Google Forms ที่มี response · rebuild dashboard live

---

## ช่วงเช้า — Core ทั้งหมด (browser-only)

| เวลา | นาที | Part | หัวข้อ | รูปแบบ | Fallback |
|---|---|---|---|---|---|
| 08:45–09:00 | 15 | — | ลงทะเบียน + เปิดเบราว์เซอร์เข้า learner link + เช็กทุกคนล็อกอิน Claude ได้ | เตรียม | ผู้ช่วยไล่เก็บคนที่ล็อกอินไม่ได้ |
| 09:00–09:15 | 15 | — | เปิดงาน + เป้าหมาย "จบวันนี้ทุกคนใช้ AI ทำงานจริง 1 ชิ้น + มีหน้าเว็บของตัวเอง" + กติกา buddy (3 คน/บัญชี) | บรรยายสั้น | — |
| 09:15–09:45 | 30 | **Part1** | **หน้า Claude (เว็บ):** กล่องพิมพ์ (Enter/Shift+Enter), แนบไฟล์ (PDF/รูป/Excel), สลับโมเดล Opus/Sonnet/Haiku, New chat, Recents *(ขยายจาก 15→30 นาที — Part1 คือฐานของทั้งวัน ไม่รีบ)* | โชว์จอ + ทำตามสด | Prompt PDF หน้า 1 |
| 09:45–10:15 | 30 | **Part2** | **ลงมือ #1 — งานจริงของตัวเอง:** คำสั่งงานการตลาด/บัญชีจริง (แคปชัน, สรุปประชุม, ตอบลูกค้า, จัด Excel) · แนบไฟล์ให้อ่าน · ลอง retry/edit | hands-on | เน็ตล่ม → วิทยากรทำโชว์ + Prompt PDF |
| 10:15–10:30 | 15 | Part1 | **Projects + Artifacts:** เก็บ context ถาวรไม่ต้องเล่าซ้ำ · แผง Artifacts (เอกสาร/ตาราง/เว็บ) copy/download | โชว์จอ | — |
| 10:30–10:45 | 15 | — | ☕ **พักเบรกเช้า** | พัก | — |
| 10:45–11:05 | 20 | **Part2** | **ลงมือ #2:** สร้าง Project แผนกตัวเอง ใส่ไฟล์+บรีฟครั้งเดียว → ให้ Claude ออก Artifact 1 ชิ้น (สรุป 1 หน้า/ตารางราคา) | hands-on | buddy ช่วยคู่ที่ติด |
| 11:05–11:15 | 10 | **Part3** | **หน้าเว็บด้วย AI (เบราว์เซอร์):** landing template คืออะไร · ให้ Claude สร้างหน้าเว็บเป็น Artifact แล้ว publish ได้เลย | โชว์จอ | Prompt PDF ส่วน landing |
| 11:15–11:55 | 40 | Part3 | **ลงมือ #3 (ไฮไลต์เช้า) — landing page ของตัวเอง:** แก้ template เป็นของแผนก/ร้านตัวเอง → publish → เปิด URL บนมือถือ | hands-on | เน็ตล่ม → เดโมทีละสเต็ป ทำต่อทีหลัง |
| 11:55–12:00 | 5 | — | สรุปเช้า + เก็บตกคนที่ยังติด | Q&A สั้น | — |
| 12:00–13:00 | 60 | — | 🍽️ **พักกลางวัน** | พัก | — |

---

## ช่วงบ่าย — Core ต่อยอด (ทำงานในเบราว์เซอร์) ‖ Advanced/Demo บนจอ (Part4)

> **Part4 (Cowork+Claude Code+Warp) เป็นก้อนเดียวตาม deck** วิทยากร 1 คนขับเดโมบนจอไล่ทีละหัวข้อย่อย **Cowork → Claude Code → Warp+deploy** (Advanced ทำตามจริงกับ buddy) · วิทยากรอีก 2 คนลอยดูแล **Core** ที่ทำงานเบราว์เซอร์คู่ขนาน · หัวข้อย่อยของ Part4 **สล็อตแยกกัน ไม่ทับกัน**

| เวลา | นาที | Part | หัวข้อ | ระดับ | Fallback |
|---|---|---|---|---|---|
| 13:00–13:10 | 10 | — | อุ่นเครื่องบ่าย + แบ่งกลุ่ม: **Advanced = 3 คนพร้อม (เบนซ์/ต่อ/นัท)** นำ buddy · ที่เหลือ **Core** ต่อยอด | — | — |
| 13:10–13:35 | 25 | **Part4** | **Cowork** — ให้ AI ทำงานกับไฟล์ในเครื่องผ่านแอป กดปุ่ม (workspace, Allow/Deny, diff ก่อน–หลัง)<br>·Core คู่ขนาน: ทำงานจริงชิ้นที่ 2 ในเบราว์เซอร์ | Advanced ทำตาม / Core ทำเบราว์เซอร์ | เดโมบนจอล้วน |
| 13:35–14:00 | 25 | **Part4** | **Claude Code (GUI)** — เปิดทั้งโปรเจกต์, Permission prompt, diff, Accept/Reject ทีละจุด<br>·Core คู่ขนาน: ขัดเกลา landing/Artifact ให้ใช้ได้จริง | Advanced ทำตาม / Core ทำเบราว์เซอร์ | เดโมบนจอล้วน |
| 14:00–14:15 | 15 | — | ☕ **พักเบรกบ่าย** | — | — |
| 14:15–14:45 | 30 | **Part4** | **Warp terminal + deploy จริง + GitHub** — พิมพ์ `claude`, Permission mode (Shift+Tab), `@`แท็กไฟล์, Slash/Skills · deploy เว็บขึ้น production · commit/push (ภาษาคน) — **บัญชี demo บนจอ** | Advanced ทำตาม / ทั้งห้อง Demo | เดโมล้วน (ไม่พึ่งเน็ตผู้เรียน) |
| 14:45–15:05 | 20 | — | **ฐานข้อมูล (Supabase/Firebase) — Demo-only:** ต่อฟอร์ม/เว็บเข้า DB เก็บข้อมูลลูกค้าจริง · เหมาะกับงานไหน · Advanced ลองต่อจริง สายอื่นดู+คิด use-case | Advanced / Demo | เดโมล้วน |
| 15:05–15:45 | 40 | — | **Capstone — ชิ้นงานจริง (แยกโจทย์):**<br>• **Core** → ปิดงานจริง 1 ชิ้น + landing page ให้เสร็จ ใช้ได้วันจันทร์<br>• **Advanced** → เว็บ+deploy หรือเชื่อม DB ให้จบ 1 flow | Core + Advanced แยกโซน | Core ทุกคนต้องได้ผลงาน ≥1 ชิ้น |
| 15:45–16:05 | 20 | — | **โชว์ผลงาน:** 5–6 คนนำเสนอ 2 นาที "ทำอะไร เอาไปใช้ที่ไหนต่อ" (ผสม Core+Advanced) | นำเสนอ | — |
| 16:05–16:30 | 25 | — | สรุป + แจก Cheat Sheet/Prompt PDF · แผนใช้ต่อ · **แบบประเมินหลังอบรม (ชุด 4)** · ปิดงาน | ปิด | ฟอร์มประเมิน = published URL เท่านั้น |

---

## หมายเหตุจากผู้ออกแบบหลักสูตร (kkai-curriculum)

- **Label Part อ้าง deck จริง** (แก้ bug ที่ slides เจอ): Part1=พื้นฐาน Claude · Part2=AI การตลาด · Part3=Landing Page · Part4=Cowork+Claude Code+Warp (ก้อนเดียว) — เดิม frontmatter อ้าง Outline เก่าผิด
  - **เช้า** เดิน Part1 → Part2 → Part3: พื้นฐาน Claude (09:15) → งานการตลาดจริง (ลงมือ#1/#2) → Landing Page (ลงมือ#3)
  - **บ่าย** = Part4 ทั้งหมด ไล่หัวข้อย่อย Cowork (13:10–13:35) → Claude Code (13:35–14:00) → Warp+deploy+GitHub (14:15–14:45) **สล็อตแยกกัน ไม่ทับกัน**
- **แก้ตามที่ slides แจ้งก่อนหน้า:**
  1. **เวลาบ่ายหัวข้อย่อยชนกัน** → แยกสล็อต Cowork/Claude Code/Warp ไม่ทับกันแล้ว (ดูด้านบน)
  2. **Part1 เวลาแน่นไป** → ขยายเลกเชอร์ Part1 จาก 15 → **30 นาที** (09:15–09:45) + hands-on ต่อเนื่องทั้งเช้า
- **น้ำหนักวัน:** เช้าทั้งหมด + Core บ่าย ≈ 75% อยู่บนเบราว์เซอร์ล้วน → สายการตลาดจบวันได้ผลงานจริง + หน้าเว็บแน่นอน
- **align กับ scope-core-advanced-demo.md v2 FINAL (ผ่าน QA):** Core (browser-only) = แกนเวลาหลักทั้งห้อง · Advanced (GitHub+deploy+DB **ทำจริง**) = stretch block คู่ buddy สำหรับ 3 คนพร้อม · Demo-only = แทรกสั้น ๆ ตอนหัวข้อเสี่ยง/เกินเวลา ฉายด้วยบัญชี demo
- **prompt/exercise:** ทุกช่วง hands-on อ้าง `lab-exercises-and-prompts.md` (Core/Advanced 2 ระดับ) · fallback เน็ตล่ม = `lab-offline-pack.pdf`
- **Fallback ฝังทุกช่วง:** เน็ตล่ม → สลับเดโมบนจอ + Prompt PDF + buddy ไม่มีช่วงที่พังทั้งคลาส
- **ข้อห้าม:** ห้าม rebuild/clear Google Forms ที่มี response · ห้าม rebuild dashboard live · ผู้เรียนใช้ learner link (2-tab) เท่านั้น
- **ต้องเช็คก่อนสอน:** ซ้อมจอจริงส่วน Part1–3 (ปุ่มอาจขยับตามเวอร์ชัน) · ยืนยันบัญชี demo สำหรับ Part4 + DB พร้อมใช้ · landing template publish ผ่านได้จริง
