# Dashboard / Forms Readiness — KKAi Workshop

วันที่ตรวจ: 2026-07-07  
Role: Dashboard/Forms  
Deadline ใหม่: ต้องปิดงานเตรียมทั้งหมดภายในวันนี้ 2026-07-07

## สรุปสั้น

Dashboard และ Google Forms ตัวหลักเปิดได้จาก public link แล้ว แต่ยังมีความเสี่ยงด้าน source/deploy และ Apps Script ที่ต้องล็อกก่อนส่งงานจบวันนี้

ลิงก์ที่ควรใช้จริงคือ learner dashboard แบบ 2 แท็บสำหรับผู้เรียน/ทีมสอน, full dashboard แบบ 3 แท็บสำหรับเจ้าของ/PM/วิทยากร, และ Google Forms published URL เท่านั้น

## ลิงก์ที่ควรใช้จริง

| ใช้กับใคร | ลิงก์ | สถานะ | หมายเหตุ |
|---|---|---|---|
| ผู้เรียน / วิทยากรหน้างาน | https://khonkaen-workshop-learner.pages.dev | ใช้จริงได้ | 2 แท็บ: ผู้เรียน + ความสอดคล้อง, default เปิดหน้า learner, มี mobile tuning เฉพาะ |
| เจ้าของ / PM / วิทยากร | https://khonkaen-ai-workshop.pages.dev | ใช้จริงได้แบบจำกัดวง | 3 แท็บครบ: เจ้าของ / ผู้เรียน / ความสอดคล้อง, มีข้อมูลความคาดหวังเจ้าของ |
| Pricing / คุยงบ | https://khonkaen-pricing.pages.dev | ใช้จริงได้ถ้าต้องคุยต้นทุน | ไม่ใช่ dashboard หลักของ workshop |
| Owner form published | https://docs.google.com/forms/d/e/1FAIpQLSd5MbOlD6K34VBNTGPXq0PMEDd1mYKzpkEp0pi48YcMy9qRBQ/viewform | ใช้จริงได้ | HTTP 200, title ตรงกับแบบสอบถามเจ้าของ |
| Learner form published | https://docs.google.com/forms/d/e/1FAIpQLSeBCuLJ6zUNICcylKvQTfng_lrnSPt10BhYijD-76ow9MJfTw/viewform | ใช้จริงได้ | HTTP 200, title ตรงกับแบบสำรวจผู้เข้าอบรม |

## ลิงก์ที่เสี่ยง / ไม่ควรแชร์

| ลิงก์ / ไฟล์ | ความเสี่ยง | วิธีใช้ที่ปลอดภัย |
|---|---|---|
| Apps Script Web App `https://script.google.com/macros/s/AKfycbymU7yf-ww9mbR5J4333dXiD5C-Ih0sj96yr22rItAd3CWt8_shKBHQxHhrZlEDfhoU/exec` | เป็น endpoint สำหรับ debug/recovery/rebuild, curl ปัจจุบัน redirect ไป login, ไม่ใช่ลิงก์ผู้ตอบ | ใช้เฉพาะ admin ที่รู้หน้าที่ของ params |
| `?form=owner`, `?form=learner`, `?form=both` | ในโน้ตเก่าบอกว่าใช้ rebuild ฟอร์ม แต่โค้ดปัจจุบัน STOP rewrite แล้วเพื่อกันข้อมูลหาย | อย่าส่งต่อเป็น workflow หลัก |
| Google Forms edit links | เปิดแก้ไขฟอร์มได้ถ้ามีสิทธิ์ | แชร์เฉพาะคนที่ต้องแก้ฟอร์มจริง |
| Duplicate form IDs `1hLEg4...`, `1mLALx...` | เป็นฟอร์มซ้ำจาก doGet trigger รอบแรก, ยังต้องลบเองใน Drive ตามโน้ต | ห้ามแชร์ให้ผู้ตอบ |
| `Files/Dashboard/Dashboard.html`, `OrgStructure.html`, `Rooms.html` | เป็นไฟล์ local/มุมเสริม ไม่ใช่ live dashboard หลักที่ระบุใน README | ใช้เป็น reference เท่านั้น |
| `/tmp/gen_combined.py`, `/tmp/kk-deploy`, `/tmp/kk-learner-deploy` | ตอนตรวจวันนี้ไม่มีไฟล์อยู่แล้ว; ถ้าจะ redeploy 2-tab ต้อง regen ใหม่ | ย้าย script/source ที่ใช้ deploy เข้า project ถาวรก่อนปิดงาน |

## สาเหตุของความเสี่ยง

- Source ของ dashboard 3 แท็บอยู่ถาวรที่ `Files/Dashboard/AI-Workshop-รวม.html`
- Source/patch ของ dashboard 2 แท็บเคยอยู่ใน `/tmp/kk-learner-deploy/index.html` และ `/tmp/gen_combined.py` ตาม `06-Dashboard-Summary.md` แต่ตรวจวันนี้ไม่พบไฟล์ใน `/tmp`
- Apps Script ปัจจุบันมี `return ContentService.createTextOutput('REWRITE DISABLED...')` ก่อนโค้ด rebuild จึงกันการ rewrite ผ่าน `doGet` แล้ว
- แต่ใน `Code.gs` ยังมี `clearAllItems()` และ `createOwnerForm()` / `createLearnerForm()` ที่ลบ item ทั้งหมด หากมีคนกด Run เองใน editor จะเสี่ยงทำให้ response เก่ากลายเป็น orphan อีก
- โปรเจกต์เคยเกิด incident ข้อมูลฟอร์มหายเมื่อ 2026-06-30 จาก `clearAllItems()` / `deleteItem()` กับฟอร์มที่มี response แล้ว และกู้คืนสำเร็จ 100%

## หลักฐานที่เช็กแล้ว

- อ่านระบบงานจาก `kkai-agent-system.md`: role dashboard ต้องตรวจ Google Forms, survey dashboard, dashboard links, mobile rendering และ safe links
- อ่าน project context จาก `README.md`, `01-Forms-Setup.md`, `05-INCIDENT-ข้อมูลหาย-กู้คืน.md`, `06-Dashboard-Summary.md`, `Files/Forms/FORM_URLS.md`
- ตรวจ HTTP วันที่ 2026-07-07:
  - `khonkaen-ai-workshop.pages.dev` = HTTP 200
  - `khonkaen-workshop-learner.pages.dev` = HTTP 200
  - `khonkaen-pricing.pages.dev` = HTTP 200
  - Owner Google Form = HTTP 200
  - Learner Google Form = HTTP 200
  - Apps Script Web App `?action=status` = redirect ไป Google login
- ตรวจ title ของ Google Forms:
  - Owner form title: `แบบสอบถามความคาดหวังสำหรับเจ้าของธุรกิจ — Claude AI Workshop`
  - Learner form title: `แบบสำรวจผู้เข้าอบรม — Claude AI Workshop`
- ตรวจข้อมูล recovered:
  - `learner_recovered.csv` มี 11 response + header
  - `owner_recovered.csv` มี 1 response + header
- ตรวจ mobile readiness จาก source/live HTML:
  - 2-tab live มี `viewport`, `overflow-x:hidden`, Thai font stack, mobile H1 split, KPI 2-column, stacked alignment table
  - 3-tab live มี `viewport` และ responsive breakpoint หลัก แต่ยังไม่ละเอียดเท่า 2-tab mobile-tuned

## Mobile readiness

| Surface | สถานะ | รายละเอียด |
|---|---|---|
| 2-tab learner dashboard | พร้อมใช้บนมือถือ | `06-Dashboard-Summary.md` ระบุว่าเคย verify 320/360/390/414/480/640/700 ด้วย puppeteer และ live HTML ปัจจุบันยังมี CSS mobile tuning อยู่ |
| 3-tab full dashboard | ใช้ได้ แต่ควรใช้กับจอใหญ่/ทีมงาน | มี responsive CSS พื้นฐาน แต่ live source ยังไม่มีชุด mobile-balance เท่าตัว 2-tab |
| Google Forms | พร้อมใช้บนมือถือ | Google Forms เป็น responsive โดยแพลตฟอร์ม, public page เปิดได้ 200 |
| Pricing calculator | ไม่ได้ตรวจเชิงภาพในรอบนี้ | HTTP 200, ใช้เฉพาะกรณีคุยราคา |

ข้อจำกัดการตรวจรอบนี้: เครื่องนี้ไม่มี browser/headless runner ที่พร้อมใช้ จึงตรวจ mobile ด้วย source/static HTML และหลักฐาน verify เดิมใน project notes ไม่ได้ถ่าย screenshot ใหม่

## วิธีแก้ก่อนปิดงานวันนี้

Immediate fix:

- ใช้ `https://khonkaen-workshop-learner.pages.dev` เป็นลิงก์หลักสำหรับแชร์หน้างาน
- ใช้ `https://khonkaen-ai-workshop.pages.dev` เฉพาะ PM/เจ้าของ/วิทยากร เพราะมีข้อมูลเจ้าของธุรกิจ
- ห้ามแชร์ Apps Script Web App, edit links, duplicate form IDs, และไฟล์ local HTML ให้ผู้เรียน
- เพิ่มโน้ตใน runbook ว่า Forms ห้าม rebuild / clear items หลังมี response

Long-term / ถ้าต้อง deploy ซ้ำวันนี้:

- เก็บ source สำหรับ 2-tab variant เข้า repo/project ถาวร เช่น `Files/Dashboard/AI-Workshop-learner.html` หรือ `Files/Dashboard/build-learner-dashboard.py`
- ถ้าต้องปรับฟอร์ม ให้แก้แบบ in-place เท่านั้น เช่น `setTitle()`, `setChoiceValues()`, หรือ add item ต่อท้าย
- ล็อก Apps Script editor ไม่ให้คนกด `createOwnerForm()` / `createLearnerForm()` โดยไม่ตั้งใจ หรือ rename ฟังก์ชันเสี่ยงเป็น `DANGEROUS_...`
- ลบ duplicate forms ใน Drive เมื่อมีสิทธิ์บัญชี `bobbysomporn@gmail.com`

## สถานะตอนนี้

พร้อมส่งลิงก์หลักได้ และ dashboard gate หลัง master decision ปิดแล้ววันที่ 2026-07-07:

- ย้าย source 2-tab ออกจาก `/tmp` แล้ว: เพิ่ม `Files/Dashboard/build-learner-dashboard.js` และ generate `Files/Dashboard/AI-Workshop-learner.html`
- ล็อก Apps Script แล้ว: `clearAllItems()` block ถ้าฟอร์มมี response, `createBothForms()` disabled, และ `action=removemenu` disabled
- เช็ก mobile 1 รอบแล้ว: headless Chromium viewport 390x844 ได้ `scrollWidth=390`, active tab = `tab-learner`, ปุ่ม tab เหลือ 2 ปุ่ม

Owner next step วันนี้:

- kkai-dashboard: ส่งไฟล์นี้ให้ PM และ QA แล้ว
- kkai-tech-setup / เจ้าของบัญชี Google: ตรวจสิทธิ์ Drive แล้วลบ duplicate forms
- kkai-pm: ยืนยันว่าจะใช้ 2-tab learner dashboard เป็นลิงก์หลักในเอกสารวันงาน
