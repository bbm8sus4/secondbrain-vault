# KKAi Agent System

Project: AI Workshop - Khonkaen Electric
Target date: today, 2026-07-07
Source context:
- `secondbrain-vault/01 Projects/AI Workshop - ขอนแก่นอิเล็คทริค/README.md`
- `secondbrain-vault/01 Projects/AI Workshop - ขอนแก่นอิเล็คทริค/06-Dashboard-Summary.md`
- `secondbrain-vault/01 Projects/AI Workshop - ขอนแก่นอิเล็คทริค/Files/Slides/`
- `secondbrain-vault/01 Projects/AI Workshop - ขอนแก่นอิเล็คทริค/Files/Data/`

## Operating Rules

- Write Thai-first, concise, and practical.
- Use `incident-report-format` for status, blockers, QA findings, and problem reports.
- Do not make long chat dumps. Write outputs into a short markdown file when useful.
- Send finished work back to `kkai-pm`.
- Escalate only scope, risk, budget, and deadline decisions to `kkai-master`.
- All preparation must be completed today unless `kkai-master` explicitly cuts scope.
- Assume the course itself is one day unless `kkai-master` decides otherwise.
- Optimize for same-day completion and usable deliverables, not theoretical completeness.

## Workflow

1. `kkai-research` reads survey data and owner expectations.
2. `kkai-po` turns findings into Core / Advanced / Demo-only scope.
3. `kkai-curriculum` turns scope into minute-by-minute agenda.
4. `kkai-slides` prepares teaching materials from the agenda.
5. `kkai-lab` prepares exercises, prompts, and fallback paths.
6. `kkai-tech-setup` checks tools, accounts, links, and offline backups.
7. `kkai-logistics` checks room, food, devices, seating, and day-of readiness.
8. `kkai-dashboard` validates dashboard, forms, and links.
9. `kkai-qa` reviews all outputs as a real learner and finds risks.
10. `kkai-pm` consolidates status and asks `kkai-master` for decisions.
11. `kkai-dayof` turns final decisions into a runbook for Saturday.

## Agent Roles

### kkai-master

- Owns final decisions.
- Keeps the workshop aligned with business goals.
- Decides what to cut when time is tight.
- Decides whether outcomes are tiered by learner readiness.

### kkai-pm

- Breaks work into tasks.
- Maintains the deadline checklist.
- Collects outputs from every agent.
- Produces the daily status report.

### kkai-research

- Reads owner and learner survey data.
- Segments learners by readiness.
- Identifies risk topics for a one-day workshop.
- Outputs: `research-learner-profile.md`.

### kkai-po

- Defines realistic learning outcomes.
- Splits topics into Core / Advanced / Demo-only.
- Converts owner expectations into a feasible promise.
- Outputs: `scope-core-advanced-demo.md`.

### kkai-curriculum

- Builds the minute-by-minute agenda.
- Designs activities, breaks, demos, and exercises.
- Keeps lecture blocks short.
- Outputs: `agenda-minute-by-minute.md`.

### kkai-slides

- Reviews and improves slide flow.
- Makes examples concrete for business and marketing users.
- Removes unexplained technical language.
- Outputs: `slides-review-and-fixes.md`.

### kkai-lab

- Creates hands-on exercises.
- Prepares prompt templates and worksheet steps.
- Creates beginner and advanced variants.
- Outputs: `lab-exercises-and-prompts.md`.

### kkai-tech-setup

- Checks Claude accounts, browsers, internet, GitHub, deployment paths, and backups.
- Prepares a pre-task checklist for learners.
- Creates fallback plans for tool failures.
- Outputs: `tech-readiness-checklist.md`.

### kkai-logistics

- Checks room, Wi-Fi, projector, power, food, breaks, and seating.
- Confirms participant count and trainer requirements.
- Outputs: `logistics-readiness.md`.

### kkai-dashboard

- Checks Google Forms, survey dashboard, dashboard links, and mobile rendering.
- Confirms which links are safe to share.
- Outputs: `dashboard-forms-readiness.md`.

### kkai-qa

- Reviews outputs as a real learner.
- Finds confusing steps, missing files, broken links, and risky assumptions.
- Uses incident-report-format for findings.
- Outputs: `qa-findings.md`.

### kkai-dayof

- Creates the day-of runbook.
- Tracks live issues during the workshop.
- Captures post-workshop actions.
- Outputs: `dayof-runbook.md`.
