# Logistics Readiness — AI Workshop ขอนแก่นอิเล็คทริค

เจ้าของ: kkai-logistics · อัปเดต: 2026-07-07
Base: `04-Menu-Catering.md`, `อบรม AI - ขอนแก่นอิเล็คทริค.md`, `Files/Dashboard/Rooms.html`
ผู้เรียน: 15 คน คละแผนก (บัญชี/การเงิน · การตลาด · วิศวกร · ช่าง) · วิทยากร 3 ท่าน · คอร์ส 1 วัน

## สรุปสถานะ (TL;DR)

**🟢 LOGISTICS พร้อมแล้ว — ยึด Plan B เป็น baseline (PM ประกาศ 2026-07-07)** ไม่รอคุณป๊อบเพื่อปิดงาน

Owner override ล่าสุด:
- ไม่ต้องพิมพ์ handout เป็นชุดกระดาษ
- ไม่ต้องรอคำตอบคุณป๊อบเพื่ออัปเกรด Plan A
- ไม่ต้องพึ่ง pre-task หรือบัญชีสำรองเพื่อให้คอร์สเดินได้

อาหาร/เบรค/งบห้อง พร้อม (ยืนยันราคา) · handout มีไฟล์ soft copy พร้อมแต่ไม่ต้องพิมพ์ · เน็ตสำรอง/offline fallback มีแผน+ตัวเลขครบ · ผังที่นั่งมีหลักการ → คอร์สเดินได้แม้ห้องไม่พร้อมอะไรเลย

- **Plan B (baseline ปัจจุบัน)** = เตรียมของสำรองมาเองทั้งหมด
- **Plan A (upgrade เมื่อได้คำตอบ 5 ข้อ)** = ใช้สเปกห้องจริง ตัดของสำรองที่ไม่ต้องใช้ออก

**ความเสี่ยงสูงสุด:** คอร์สให้ deploy เว็บ + ต่อฐานข้อมูล = ออกเน็ตพร้อมกัน 15+ เครื่องทั้งวัน ถ้า Wi‑Fi ห้องไม่ไหว คอร์สพัง → แผน B แก้ตรงนี้เป็นอันดับแรก

## ✅ พร้อมแล้ว (ยืนยันข้อมูล)

| รายการ | สถานะ | หมายเหตุ |
|---|---|---|
| ห้องประชุม | ✅ ราคายืนยัน | ฿3,745/วัน รวม VAT |
| อาหารกลางวัน | ✅ เมนูล็อก | SHIFT ฿190/เซต · 15 เมนู · มีข้าว+ผลไม้+น้ำ |
| เบรคเช้า | ✅ | เครื่องดื่มเย็น ฿70 + Break Set ฿49 |
| เบรคบ่าย | ✅ | เครื่องดื่มเย็น ฿70 + Break Set ฿49 |
| งบ catering | ✅ | ฿428/หัว/วัน → 15 คน ≈ ฿6,420 |
| น้ำเปล่า | ✅ | รวมในเซตอาหาร (ขวด/คน) |
| Lab content | ✅ | Browser-only fallback + Prompt/Template Pack พร้อมแล้ว |
| Dashboard gate | ✅ | Source 2-tab ถาวร, Apps Script clear/delete ล็อกแล้ว, mobile 390x844 ผ่าน |

## 5 คำถามที่ส่งถามคุณป๊อบแล้ว (Discord + master ช่วยดัน)

1. Wi‑Fi ห้อง — รับกี่อุปกรณ์พร้อมกัน? ความเร็วเท่าไร?
2. ปลั๊กไฟ/รางปลั๊ก — มีพอเสียบ 15 โน้ตบุ๊กทั้งวันไหม?
3. จอ/โปรเจกเตอร์ — มี HDMI ไหม? รองรับ Mac (USB‑C) ไหม?
4. ผู้เรียนมีโน้ตบุ๊กครบ 15 คนไหม? ใครไม่มี?
5. ผัง/ขนาดห้อง + เวลาเข้าถึงห้องเพื่อเซ็ตอัพ

> คำตอบเข้าเมื่อไร → เดินหน้าตาม **แผน A** และตัดของสำรองแผน B ที่ไม่ต้องใช้ออก

---

## แผน A — ได้สเปกห้องแล้ว (best case: เช็กลิสต์ยืนยันหน้างาน)

ทำเมื่อคุณป๊อบ/ผู้ดูแลห้องยืนยันสเปกครบ

- [ ] **Wi‑Fi** ยืนยันรับ 18–20 เครื่อง (ดู target bandwidth ในส่วน internet ด้านล่าง) → ทดสอบ push GitHub / deploy / npm จริงก่อนวันงาน
- [ ] **ปลั๊ก** รางปลั๊กถึงทุกโต๊ะ, ยืนยันเบรกเกอร์ไม่ทริปเมื่อโหลด 15 เครื่อง
- [ ] **จอ** มี HDMI + ทดสอบ adapter Mac, ภาพคมอ่านโค้ดออกจากหลังห้อง
- [ ] **โน้ตบุ๊ก** รู้จำนวนคนที่ไม่มีเครื่อง → บริษัทเตรียม/ยืม/จับคู่
- [ ] **ผังที่นั่ง** วาง layout ตามห้องจริง (ดูหลักการด้านล่าง)

## แผน B — ยังไม่ได้สเปก / สมมติแย่สุด (เตรียมของสำรองมาเอง — ค่าตั้งต้น)

สมมติ: Wi‑Fi ห้องไม่พอ · ปลั๊กไม่พอ · ไม่มี adapter · มีผู้เรียนบางคนไม่มีโน้ตบุ๊ก → เตรียมให้คอร์สเดินได้แม้ห้องไม่ช่วยอะไรเลย

- **เน็ตสำรอง (สำคัญสุด)** → ดูส่วน **"Plan B — อินเทอร์เน็ตสำรอง"** ด้านล่าง (kkai-tech-setup): แนะนำ 4–5 uplink แยกค่าย, target 30–50 Mbps down / 10–20 Mbps up, offline fallback (zip template/npm cache/static HTML/PDF/local dashboard), staged deploy 3–5 คน
- **ปลั๊ก** — เอารางปลั๊กมาเอง 4–5 ราง + ขอผู้เรียนชาร์จเต็มมาจากบ้าน
- **จอ** — เอา adapter USB‑C→HDMI + สาย HDMI ยาวมาเอง (เผื่อทั้ง Mac/Windows)
- **โน้ตบุ๊ก** — สมมติมีคนไม่มีเครื่อง → แผนจับคู่ (pair) 2 คน/เครื่องสำหรับสายที่ไม่ deploy เอง + เตรียมเครื่องสำรอง 1–2 เครื่องถ้าหาได้
- **ผังที่นั่ง** — จัดตามหลักการด้านล่างได้เลยแม้ยังไม่รู้ layout

### หลักการผังที่นั่ง (ใช้ได้ทั้ง A/B)
- จัด 3–4 คน/โต๊ะ, คละสายเทคนิค + สายการตลาด (คนเร็วช่วยคนช้า), แบ่งโต๊ะให้ตรงกับกลุ่ม uplink (Core / Advanced-A / Advanced-B)
- วิทยากรเดินถึงทุกโต๊ะได้
- อ้างอิงแผนกจาก `Files/Dashboard/Rooms.html` (ผังออฟฟิศจริง: Marketing ห้อง 206, EasySlip/Product ห้อง 209 — ผู้เรียน 9/11 สายการตลาด)
- ⚠️ Rooms.html = ผังห้องออฟฟิศ ไม่ใช่ห้องอบรม — ห้องอบรมวาง layout ใหม่ตามห้องจริง

## ⏳ ต้องยืนยันเพิ่ม (ไม่ block)

- เวลาเริ่ม–เลิก + เบรคเช้า/เที่ยง/บ่าย (รอ agenda จาก kkai-curriculum เพื่อ sync catering)
- แอร์/อุณหภูมิห้อง, แสงสว่างพออ่านจอ, ป้าย/ทางเข้า, ที่จอดรถ, ถังขยะเก็บกล่องอาหาร
- **PDF handout:** kkai-tech export Prompt/Template Pack เป็น PDF (Print→Save as PDF) → **logistics พิมพ์แจกหน้างาน** (ดู gate ด้านล่าง)

## 🖨️ Gate วันนี้ — พิมพ์ + แจก Handout หน้างาน (logistics owns)

รับ PDF Prompt/Template Pack จาก kkai-tech → พิมพ์ + จัดแจกหน้างาน

**ชุดพิมพ์ (แยกตามคนดู — ไม่ใช่ของซ้ำ, ตรวจไฟล์แล้ว ✅):**

| ไฟล์ | หน้า | แจกให้ใคร | จำนวน |
|---|---:|---|---:|
| `lab-offline-pack.pdf` (lab, Playwright · แก้ตาม QA แล้ว: อธิบาย CTA เป็นภาษาคน · 150KB) | 5 | **ผู้เรียนทุกคน** — เป้าหมาย+กฎ+คลัง prompt+template offline | 15 + สำรอง 3 = **18** |
| `handouts/kkai-lab-handout-full.pdf` (tech) | 6 | **วิทยากร/พี่เลี้ยง** — คู่มือสอน scope 3 ชั้น+เกณฑ์ผ่าน+ทางสำรอง | 3 + สำรอง 2 = **5** |
| ~~`handouts/kkai-prompt-template-pack.pdf`~~ (1 หน้า) | 1 | เลิกใช้ — เนื้อหาถูกรวมใน lab-offline-pack แล้ว | — |

รวม ≈ 5×18 + 6×5 = **120 หน้า** ขาวดำ

- [x] รับ + ตรวจไฟล์ทั้งหมด (valid A4, โค้ด/prompt ไม่ตกขอบ, อ่านออกขาวดำ)
- [x] เลือกชุดพิมพ์ + retire ตัวซ้ำ (prompt-pack 1 หน้า)
- [ ] **พิมพ์:** learner-pack 18 ชุด + trainer-guide 5 ชุด
- [ ] เย็บ/คลิปต่อชุด กันหน้ากระจาย
- [ ] วาง learner-pack 1 ชุด/ที่นั่งก่อนเข้า + trainer-guide บนโต๊ะวิทยากร

**แผน A (มีเวลา):** พิมพ์ล่วงหน้าที่ร้าน/ออฟฟิศ เย็บเสร็จก่อนวันงาน ← ไฟล์พร้อมทั้งหมด ทำได้เลย
**แผน B (นาทีสุดท้าย):** พิมพ์เช้าวันงานร้านใกล้ venue/ปริ้นเตอร์บริษัท; พิมพ์ไม่ทัน = แจก PDF soft copy + learner 2-tab link กันพลาด

> ✅ dependency ปลดหมดแล้ว (lab render เอง ไม่ต้องรอ tech) — เหลือ **การพิมพ์จริง** (งานหน้างานของคน)

## Plan B — อินเทอร์เน็ตสำรองถ้า Wi‑Fi ห้องไม่พอ

### คำตอบสั้น

ถ้าต้องรองรับ **15 ผู้เรียน + 3 วิทยากร + เครื่องสำรอง** ทั้งวัน และยังมีช่วง GitHub/deploy/database:

- **ขั้นต่ำที่รับได้:** 3 uplink รวมกัน
  - Wi‑Fi ห้อง 1 เส้น
  - มือถือ hotspot/pocket Wi‑Fi 2 ตัว แยกค่าย
- **แนะนำจริง:** 4–5 uplink รวมกัน
  - Wi‑Fi ห้อง 1 เส้น
  - hotspot/pocket Wi‑Fi 3 ตัว แยกค่าย
  - มือถือวิทยากร 1 ตัวเป็น emergency admin-only
- **ไม่แนะนำ:** pocket Wi‑Fi ตัวเดียวให้ทั้งห้อง เพราะติด client limit, สัญญาณตก, และ throttling หลังใช้ data หนัก

### 1) Pocket Wi‑Fi / แชร์เน็ตมือถือกี่ตัวพอ

แผนแบ่งกลุ่ม:

| Uplink | ใช้กับใคร | จำนวนเครื่อง | หมายเหตุ |
|---|---:|---:|---|
| Wi‑Fi ห้อง | Core group / browsing / Claude | 8–10 | ใช้เป็น default ถ้าเสถียร |
| Hotspot A | Advanced group 1 | 4–5 | GitHub/deploy/database |
| Hotspot B | Advanced group 2 | 4–5 | GitHub/deploy/database |
| Hotspot C | วิทยากร + backup | 3–5 | demo, deploy ผ่านบัญชีวิทยากร, emergency |
| Hotspot D (ถ้ามี) | สำรอง | 0–5 | เปิดเมื่อเส้นใดเส้นหนึ่งล่ม |

คำแนะนำ:
- ใช้ **SIM คนละค่ายอย่างน้อย 2 ค่าย** เพื่อลด risk เสาสัญญาณเต็ม
- เปิด hotspot เฉพาะกลุ่ม ไม่ให้ทั้งห้องเกาะเส้นเดียว
- ตั้งชื่อ SSID ชัดเจน เช่น `KKAi-Core`, `KKAi-Advanced-A`, `KKAi-Advanced-B`, `KKAi-Trainer`
- จำกัดงาน deploy จริงให้เฉพาะ Advanced group; Core ใช้ browser-only + template
- ถ้ามี pocket Wi‑Fi ที่จำกัด 5–10 clients ให้จับกลุ่มตามโต๊ะ ไม่ให้เกิน client limit

จำนวน data ที่ควรเตรียม:
- ขั้นต่ำ: **100 GB รวมทั้งวัน**
- แนะนำ: **150–200 GB รวมทั้งวัน** ถ้ามี npm install / image assets / Claude / video call / dashboard พร้อมกัน
- หลีกเลี่ยงการให้ทุกคน `npm install` พร้อมกันผ่านมือถือ เพราะ data และความเร็วจะตกเร็วมาก

### 2) Offline fallback / Deploy fallback

ต้องเตรียมก่อนวันสอน:

- [ ] Repo/template แบบ zip สำหรับแจก offline
- [ ] `node_modules` หรือ npm cache สำหรับ template หลักบนเครื่องวิทยากร/USB
- [ ] หน้า landing template แบบ static HTML/CSS ที่เปิดจากไฟล์ได้ ไม่ต้อง `npm install`
- [ ] Prompt PDF + worksheet PDF สำหรับ Core group
- [ ] Prompt/Template Pack PDF handout จาก `lab-exercises-and-prompts.md` ด้วย Print -> Save as PDF
- [ ] Dashboard learner 2-tab เป็น local HTML/PDF/screenshot
- [ ] Slides PDF ทุก part
- [ ] ไฟล์ data ตัวอย่าง CSV/JSON ในเครื่อง ไม่ต้องดึงจาก cloud
- [ ] บัญชี demo ของวิทยากร login Claude/GitHub/deploy provider ไว้แล้ว

ถ้าเน็ตล่มบางส่วน:
- Core group ทำงานต่อใน browser/local template + prompt PDF
- Advanced group ลดเหลือ pair programming และใช้ hotspot เฉพาะกลุ่ม
- วิทยากร deploy ให้ดูผ่านบัญชี demo หรือเครื่องเดียว ไม่ให้ทุกคน deploy พร้อมกัน
- Database ใช้ demo-only หรือ local mock JSON แทน Supabase/Firebase

ถ้าเน็ตล่มทั้งห้อง:
- ตัด GitHub/deploy/database เป็น demo-only
- ใช้ slides PDF + prompt PDF + local landing template
- ให้ผู้เรียนทำ prompt/workflow ของงานจริงและปรับ copy/content ใน local file
- เก็บงานไว้ในเครื่อง แล้วค่อยส่ง/deploy หลังเน็ตกลับ

### 3) ประเมิน bandwidth ต่อหัว

ตัวเลขใช้งานจริงแบบ conservative:

| กิจกรรม | ต่อคนโดยประมาณ | หมายเหตุ |
|---|---:|---|
| Claude chat + dashboard/forms | 0.2–1 Mbps | burst เป็นช่วง ๆ |
| Git push งาน static เล็ก | 1–20 MB ต่อรอบ | bandwidth ไม่หนัก แต่ต้อง latency เสถียร |
| Deploy static site | 1–50 MB ต่อรอบ | หนักตอน upload assets |
| `npm install` สด | 50–300+ MB ต่อคน | ตัวทำเน็ตพังถ้าทำพร้อมกัน |
| เปิด docs/GitHub/Cloudflare | 0.5–2 Mbps | หนักถ้าโหลดพร้อมกัน |
| Database console | 0.5–2 Mbps | ต้องเสถียรมากกว่าต้องเร็ว |

แนะนำ capacity:
- Core browsing/Claude: **1 Mbps ต่อคน** พอใช้งาน
- Advanced deploy: **3–5 Mbps ต่อคนช่วง burst**
- ทั้งห้อง 18–20 อุปกรณ์: ควรมี downlink รวม **30–50 Mbps** และ uplink รวม **10–20 Mbps**
- ถ้าต่ำกว่านี้ ให้ใช้ staged deploy: deploy ทีละ 3–5 คน หรือวิทยากร deploy ให้ดู

### กติกาหน้างานเพื่อไม่ให้เน็ตพัง

- ห้ามทุกคน `npm install` พร้อมกัน
- ห้ามทุกคน deploy พร้อมกัน ให้แบ่งรอบ Advanced ทีละกลุ่ม
- ปิด sync หนัก ๆ เช่น cloud backup, OS update, app update
- แจก template/cache ล่วงหน้า
- ให้ Core ใช้ learner 2-tab link เท่านั้น: `https://khonkaen-workshop-learner.pages.dev`
- 3-tab dashboard ใช้เฉพาะ PM / เจ้าของ / วิทยากร
- ถ้าเริ่มเห็น latency สูง ให้ย้าย GitHub/deploy/database เป็น Demo-only ทันที

## ETA (2026-07-07)

- **แผน B พร้อมแล้ววันนี้** — internet fallback มีตัวเลขจาก kkai-tech-setup ครบ (4–5 uplink, offline fallback), เหลือรวบของสำรอง (รางปลั๊ก/adapter/HDMI) + จัดผังที่นั่งตามหลักการ → ทำได้เย็นนี้
- **แผน A** — ปิดได้ภายในเย็นนี้ทันทีที่คุณป๊อบตอบ 5 คำถาม
- ไม่มีการบล็อกทั้งชิ้น: คอร์สเดินได้ด้วยแผน B แม้คุณป๊อบยังไม่ตอบ

## ต้องการจากทีมอื่น

- **kkai-pm/master → คุณป๊อบ:** ดัน 5 คำถามให้ได้คำตอบวันนี้ (สเปกห้อง + โน้ตบุ๊กผู้เรียน)
- **kkai-tech-setup:** ✅ ตัวเลขเน็ตสำรอง/offline fallback แล้ว · ⏳ รอ **PDF Prompt/Template Pack** (Print→Save as PDF) ส่งให้ logistics เพื่อพิมพ์แจก — เป็น dependency เดียวของ handout gate
- **kkai-curriculum:** เวลาเบรค/พัก เพื่อ sync catering
