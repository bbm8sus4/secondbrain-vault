# KKAi Workshop — PM Status & Deliverable Checklist

อัปเดต: 2026-07-07 (เดดไลน์เตรียมงาน = วันนี้)
เจ้าของงาน: คุณป๊อบ (ขอนแก่นอิเล็คทริค) · ผู้เรียน 15 คน (ตอบสำรวจ 11, 9/11 สายการตลาด, มั่นใจเฉลี่ย 2.7/5)

## Deliverable checklist (ปลายทาง = workspace root `/home/thunder-management/workspaces/seatmap/`)

| # | ไฟล์ | เจ้าของ | สถานะ |
|---|------|--------|-------|
| 1 | research-learner-profile.md | kkai-research | ✅ ส่งแล้ว (tier 3/4/4, แนะ DB+GitHub demo-only) |
| 2 | scope-core-advanced-demo.md | kkai-po | ✅ ส่งแล้ว (Core/Advanced/Demo-only) |
| 3 | agenda-minute-by-minute.md | kkai-curriculum | ✅ FINAL (timing บ่ายแก้แล้ว, Part1 15→30น.) |
| 4 | slides-review-and-fixes.md | kkai-slides | ✅ FINAL (เวลา/flow/ศัพท์/ปุ่มตรง agenda; verify 0 เวลาเก่าตกค้าง) |
| 5 | lab-exercises-and-prompts.md | kkai-lab | ✅ ส่งแล้ว (Core/Adv/Demo + fallback F1-F7 + prompt pack) |
| 6 | tech-readiness-checklist.md | kkai-tech-setup | ✅ doc + ติดตั้ง wrangler/gh + pre-task พร้อม (ค้าง=login+2บัญชี ต้องคน) |
| 7 | logistics-readiness.md | kkai-logistics | ✅ 2 แผน (A=มีสเปกห้อง / B=สำรองแย่สุด) — คอร์สเดินได้แม้ owner เงียบ |
| 8 | dashboard-forms-readiness.md | kkai-dashboard | ✅ + gate ปิดแล้ว (source persist, Apps Script ล็อก, mobile ผ่าน) |
| 9 | qa-findings.md | kkai-qa | ✅ PASS — content ผ่านเต็ม (alignment ปิดครบ; เหลือแค่ gate กายภาพ/คน) |
| 10 | dayof-runbook.md | kkai-dayof | ✅ v3 FINAL — พร้อมใช้หน้างาน (baseline=Plan B, มีบล็อก Plan A/B + Go/No-Go เช้า) |

## 🎉 เตรียมงานเสร็จสมบูรณ์ — 10/10 FINAL + QA PASS
Baseline = **Plan B** (master อนุมัติ) → คอร์สวันเสาร์รันได้ชัวร์ ไม่ต้องรอใคร. Plan A = upgrade ถ้า owner ตอบ.

### Owner override — ตัดออกจากแผนแล้ว

รายการต่อไปนี้ **ไม่ต้องทำและไม่ใช่ checklist ค้าง**:
- ไม่ต้อง login บัญชี Claude สำรอง 2 บัญชีบนเครื่องสอน
- ไม่ต้องส่ง pre-task ให้ผู้เรียนหรือเก็บคำตอบ
- ไม่ต้อง login Cloudflare / GitHub เพื่อโชว์ deploy สด
- ไม่ต้องพิมพ์ handout เป็นชุดกระดาษ
- ไม่ต้องรอคำตอบคุณป๊อบเพื่ออัปเกรด Plan A

### สถานะใช้งานจริงหลัง override

ใช้แผนที่เสร็จแล้วได้ทันที:
- Core browser-only เป็นแกนหลัก
- Advanced / deploy / database ใช้เป็น demo หรือข้ามได้ตามเวลาจริง
- ใช้ learner 2-tab เป็นลิงก์หลัก
- ใช้ไฟล์ handout/PDF ที่มีอยู่เป็น soft copy ถ้าจำเป็น

## เนื้อหาจริงที่พร้อมรีวิวแล้ว (ใน `.tmp-ai-workshop/AI Workshop - ขอนแก่นอิเล็คทริค/`)
- Slides: Files/Slides/Part1-4 (.md + .pdf)
- Curriculum/agenda: Files/Curriculum/Outline-Cowork-ClaudeCode-Warp, CheatSheet-PreTask
- Dashboard (live): khonkaen-workshop-learner.pages.dev (หน้างาน), khonkaen-ai-workshop.pages.dev (PM/owner), khonkaen-pricing.pages.dev
- Forms + FORM_URLS.md, Survey analysis HTML, Costs/Pricing-Calculator.html

## ความเสี่ยงที่ต้องปิดวันนี้ (จาก Tech + Dashboard + talk-with-me)
1. เครื่องนี้ไม่มี wrangler / gh / clasp → deploy สด/แก้ Apps Script ไม่ได้ → ต้องใช้ live link ที่มีอยู่ ห้าม rebuild
2. Google Forms เคยมี incident ข้อมูลหาย (clearAllItems) → **ห้าม rebuild/clear ฟอร์มที่มี response**
3. Dashboard 2-tab: ✅ ปิดแล้ว — ย้าย source ออกจาก `/tmp` เป็น `Files/Dashboard/build-learner-dashboard.js` + `AI-Workshop-learner.html`
4. ฟอร์มซ้ำใน Drive ยังต้องลบ
5. ผู้เรียนยังไม่ชัดเรื่องบัญชี Claude/GitHub + สิทธิ์ติดตั้งเครื่อง → ไม่เป็น blocker หลัง override เพราะ Core เป็น browser-only และ Advanced ไม่บังคับ
6. Scope เดิมหนักเกิน 1 วันสำหรับผู้เรียนเฉลี่ย (มั่นใจ 2.7/5)

## ต้องให้ kkai-master ตัดสินวันนี้
- ✅ **A. ตัด scope แล้ว** เป็น 3 ชั้น:
  - Core: ทุกคน, browser-only, Claude + งานจริง + landing template
  - Advanced: คนพร้อม + buddy, GitHub + deploy + database ทำจริง
  - Demo-only: ฉายจอด้วยบัญชี demo สำหรับหัวข้อที่เสี่ยงหรือเกินเวลา
- ✅ **B. Fallback tech/deploy ตัดสินแล้ว**:
  - Link หลัก = learner 2-tab เท่านั้น
  - 3-tab ใช้เฉพาะ PM / เจ้าของ / วิทยากร
  - เน็ตล่ม = demo + prompt PDF + buddy
  - ห้าม rebuild / clear Google Forms ที่มี response แล้ว

## Gate วันนี้หลัง master decision

- Tech: ✅ ไม่มี gate ค้างหลัง owner override — ไม่ต้อง login `wrangler` / `gh`, ไม่ต้องบัญชี Claude สำรอง, ไม่ต้องส่ง pre-task
- Dashboard: ✅ ย้าย source 2-tab ออกจาก `/tmp`, ✅ ล็อก Apps Script จุด `clearAllItems`, ✅ เช็ก mobile 1 รอบ
- Lab: ✅ browser-only fallback + Prompt/Template Pack เสร็จแล้ว · ไม่ต้องพิมพ์ handout
- PM: รวม checklist ทั้งหมดตาม scope 3 ชั้น

## Link ที่ตกลงใช้จริง
- หน้างาน/ผู้เรียน: https://khonkaen-workshop-learner.pages.dev
- PM/owner/วิทยากร: https://khonkaen-ai-workshop.pages.dev
- Google Forms: published URL เท่านั้น
