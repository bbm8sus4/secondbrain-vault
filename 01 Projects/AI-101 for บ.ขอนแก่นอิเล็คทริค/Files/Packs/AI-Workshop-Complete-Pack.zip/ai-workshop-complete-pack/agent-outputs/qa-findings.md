# QA Findings — AI Workshop ขอนแก่นอิเล็คทริค

วันที่ตรวจ: 2026-07-07  
Role: kkai-qa  
สถานะ: **Content QA ผ่านครบแล้ว เหลือ gate กายภาพ/ปฏิบัติการ**

## สรุปสั้น

ยืนยันตามที่ PM ขอ: เนื้อหา workshop ทั้งชุดควรผ่านเต็มได้แล้วหลัง re-verify รอบล่าสุด

สิ่งที่ยังค้างไม่ใช่ content แล้ว แต่เป็น gate กายภาพ/ปฏิบัติการ:

- Tech: login บัญชี Claude สำรอง 2 ชุด + ส่ง pre-task ให้ผู้เรียนจริง
- Logistics/owner: 5 คำถามห้องจริง/อุปกรณ์/โน้ตบุ๊ก/ผังที่นั่ง + รูปสินค้า โดยมี Plan B คุมความเสี่ยง

## ชิ้นงานที่ QA รีวิวแล้ว

1. `research-learner-profile.md`
2. `scope-core-advanced-demo.md` FINAL v2
3. `agenda-minute-by-minute.md` FINAL
4. `slides-review-and-fixes.md` FINAL
5. `lab-exercises-and-prompts.md`
6. `lab-offline-pack.pdf`
7. `lab-offline-pack.html`
8. `tech-readiness-checklist.md`
9. `dashboard-forms-readiness.md`
10. `logistics-readiness.md`
11. `pm-status.md`

## Re-verify ล่าสุด

### Agenda / Slides / Lab Alignment

ผ่านแล้ว

- `agenda-minute-by-minute.md` map deck จริงถูกต้อง:
  - Part1 = พื้นฐาน Claude
  - Part2 = AI การตลาด
  - Part3 = Landing Page
  - Part4 = Cowork + Claude Code + Warp
- Lab ใช้ flow เดียวกัน: Core browser-only ตอนเช้า/บ่าย, Advanced เป็น stretch, Demo-only เป็น fallback
- Agenda แก้ประโยค scope ให้ตรง v2 แล้ว: Advanced ทำจริงได้สำหรับคนพร้อม + buddy; Demo-only ใช้ตอนเสี่ยง/เกินเวลา

### Slides Final

ผ่านแล้ว

- ตรวจไฟล์สไลด์จริงใน `.tmp-ai-workshop/.../Files/Slides/`
- ไม่พบเวลาเก่า `13:15`, `13:30`, `15:00`, หรือข้อความ flow เก่าใน deck actual
- Part2 "ต่อจากนี้" ชี้ไป Part3 Landing ช่วงเช้า
- Part3 "ต่อจากนี้" ชี้ไปพักเที่ยง → Part4 บ่าย → capstone/ปิดงาน
- CTA/PDPA/deploy/framework/publish wording ถูกแก้ตาม slides review แล้ว

หมายเหตุ:

- `slides-review-and-fixes.md` ยังมี old findings ในส่วน historical review ด้านล่าง แต่หัวไฟล์ระบุ FINAL และ deck actual สะอาดแล้ว จึงไม่ถือเป็น blocker
- รูปสินค้าผู้เรียนยังเป็น logistics/owner input ไม่ใช่ blocker ของ deck เพราะมี placeholder/fallback ใน lab/offline pack

### Lab / Offline Pack

ผ่านแล้ว

- Core ทำจบด้วย browser ล้วนได้จริง: `claude.ai` + prompt + Artifacts/template
- เกณฑ์ผ่านใน lab ชัดพอสำหรับผู้เรียนมั่นใจเฉลี่ย 2.7/5
- Prompt copy-paste ใช้งานได้จริง มีช่อง `[แก้ตรงนี้]`
- Fallback F1-F7 ครอบ login, Wi-Fi, publish, Warp ยาก, คนเร็ว, คนช้า, ไฟ/โปรเจกเตอร์
- `lab-offline-pack.pdf` = A4 5 หน้า, font Thai embedded, พิมพ์แจกได้
- `lab-offline-pack.html` เปิดออฟไลน์ได้
- Offline pack เพิ่มคำอธิบาย CTA แล้ว

### Dashboard / Forms

ผ่านแล้ว

- Learner 2-tab เป็น link หลัก: `https://khonkaen-workshop-learner.pages.dev`
- 3-tab จำกัด PM / owner / trainers
- Dashboard gate ปิดแล้ว: source persisted, Apps Script clear/delete locked, mobile 390x844 passed
- ใช้ Google Forms published URL เท่านั้น

## Gate ที่ยังต้องปิด

### Gate 1 — Tech / Account

ความรุนแรง: สูง  
Owner: PM / คุณป๊อบ / Tech setup

ยังค้าง:

- Login บัญชี Claude สำรอง 2 ชุดให้ใช้จริงในห้อง
- ส่ง `pre-task-message-to-learners.md` ให้ผู้เรียนจริง
- รวบรวมคำตอบ pre-task เรื่องโน้ตบุ๊ก, login, install, GitHub, รูปสินค้า

ไม่ใช่ blocker content:

- `wrangler` และ `gh` ติดตั้งแล้ว
- Login `wrangler`/`gh` เป็น optional เฉพาะถ้าจะ demo deploy สด
- ถ้า login deploy ไม่พร้อม ให้ใช้ Demo-only/live link ตาม fallback

### Gate 2 — Logistics / Owner

ความรุนแรง: สูง  
Owner: PM / Logistics / คุณป๊อบ

ยังค้าง:

- Wi-Fi/อินเทอร์เน็ตห้องจริง
- ปลั๊กไฟ/รางปลั๊ก
- จอ/โปรเจกเตอร์/สาย/adapter
- ผู้เรียนมีโน้ตบุ๊กครบไหม
- ผังที่นั่งตาม buddy/tier
- รูปสินค้า/โปรโมชันจริง ถ้ามี

Plan B:

- Logistics มี Plan B แล้วสำหรับกรณี owner เงียบหรือสเปกห้องไม่พร้อม
- Offline pack + prompt PDF + buddy + demo account ช่วยคุมความเสี่ยงเน็ต/เครื่องมือ
- ถ้า Advanced setup เสี่ยง ให้เปลี่ยนเป็น Demo-only ทันที

## Final QA Verdict

Content: **ผ่าน**

Scope: **ผ่าน**

Slides/Agenda/Lab alignment: **ผ่าน**

Fallback/offline pack: **ผ่าน**

Dashboard/forms: **ผ่าน**

เหลือก่อนสอนจริง:

1. PM/Tech login บัญชี Claude สำรอง 2 ชุด
2. PM ส่ง pre-task และเก็บคำตอบ
3. Logistics/PM ปิด 5 คำถาม owner หรือใช้ Plan B

ถ้า 3 ข้อนี้ปิดหรือประกาศใช้ Plan B ชัดเจนแล้ว QA ไม่มี content blocker เหลือ
