# Scope: Core / Advanced / Demo-only — AI Workshop ขอนแก่นอิเล็คทริค

> เจ้าของ: kkai-po · วันที่: 2026-07-07 · สถานะ: **FINAL (v2 — ล็อกตาม master decision)**
> คอร์ส 1 วัน · ผู้เรียน 11 คน (9/11 สายการตลาด · มั่นใจเฉลี่ย 2.7/5 · 6/11 ไม่เคยเขียนโค้ด · 1 คนใช้ Claude ประจำ)
> Input: research-learner-profile.md + 06-Dashboard-Summary + gaps + master decision (final)

---

## 1. สรุปการตัดสินใจ (master ล็อกแล้ว)

**Scope 3 ชั้น — ยึดตามนี้เป็นทางการ:**

| ชั้น | ใคร | ทำอะไร | หลักการ |
|---|---|---|---|
| **Core** | ทุกคน | **browser-only** · Claude + งานจริง + landing page จาก template | ไม่ต้องติดตั้งอะไร ทำบนเบราว์เซอร์ล้วน → ทั้งห้องสำเร็จ 100% |
| **Advanced** | คนพร้อม + buddy | GitHub + deploy + database **ทำจริง** | คนกลุ่มพร้อมลงมือจริง มี buddy ช่วยคนที่ตาม |
| **Demo-only** | วิทยากรฉายจอ | หัวข้อที่เสี่ยงหรือเกินเวลา — **ฉายด้วยบัญชี demo** | ผู้เรียนดูให้เข้าใจ ไม่ต้องทำเอง ไม่ยุ่งของจริง |

**เปลี่ยนจาก v1:** Core เป็น **browser-only** (ตัด install ออกหมด) · DB/GitHub ย้ายจาก Demo-only → **Advanced ทำจริง** (สำหรับคนพร้อม) · Demo-only กลายเป็น *กลไกสำรอง* (ฉายด้วยบัญชี demo) สำหรับของเสี่ยง/เกินเวลา ไม่ใช่หัวข้อตายตัว

---

## 2. กลุ่มผู้เรียน + buddy pairing

| กลุ่ม | คน | คะแนนพร้อม | แนวทาง |
|---|---|---|---|
| **พร้อม (นำ Advanced + เป็น buddy)** | เบนซ์ 95 · ต่อ 88 · นัท 80 | 80–95 | ทำ Core เร็ว → Advanced (GitHub/deploy/DB จริง) · ช่วยเพื่อน |
| **กลาง (Core เต็ม + แตะ Advanced)** | ฟ้า 60 · อาย 55 · เจ 52 · แบ๊ก 48 | 48–60 | Core ให้แน่น ต่อ Advanced ถ้าไหว |
| **เริ่มต้น (Core ให้สำเร็จ)** | หมี 40 · โดนัท 35 · ยิม 30 · มอส 15 | 15–40 | เป้า = Core สำเร็จ 100% · จับคู่กับกลุ่มพร้อม |

**Buddy:** 1 คนพร้อม + 1–2 คนเริ่มต้น · เบนซ์ (หัวหน้างานช่าง ใช้ Claude ประจำ) นำสายเทคนิค

---

## 3. ตารางขอบเขตรายหัวข้อ

| หัวข้อ | Core (ทุกคน · browser-only) | Advanced (คนพร้อม + buddy · ทำจริง) | Demo-only (ฉายด้วยบัญชี demo) |
|---|---|---|---|
| **1. Claude** | ล็อกอินบนเว็บ · เขียน prompt งานจริง (การตลาด/เอกสาร/สรุป) | ใช้ Projects + ไฟล์แนบเป็นระบบ · Claude Code เบื้องต้น | ฟีเจอร์ลึกที่เสี่ยง/เกินเวลา |
| **2. ทำเว็บ** | ทำ **landing page ด้วย Claude Artifacts / template** ได้หน้าจริงบนเว็บ (no-code, ไม่ต้อง deploy tool — QA ยืนยันทำได้ใน 1 วันด้วยวิธีนี้เท่านั้น) | แก้โครงสร้าง/โค้ดเอง · **deploy จริง** (Cloudflare/Netlify) — stretch | pipeline เต็มถ้าเวลาไม่พอ → ฉาย demo แทน |
| **3. ฐานข้อมูล** | เข้าใจ DB คืออะไร + เก็บข้อมูลผ่าน Sheet/Form แบบง่าย | **ต่อ Supabase/Firebase กับเว็บจริง** | schema/query เชิงลึก → ฉาย demo |
| **4. GitHub** | รู้ว่า GitHub คืออะไร ทำไมต้องใช้ (ดูบนเว็บ) | **push repo จริง + เชื่อม deploy** | branch/PR/collab flow → ฉาย demo |
| **5. AI ในงานจริง** | prompt การตลาด/คอนเทนต์ (จุดแข็งห้อง) | ต่อ automation (Make/Zapier + AI) | — |

---

## 4. Fallback (ยึดตาม master + PM)

- **Link หลักหน้างาน = learner 2-tab เท่านั้น:** https://khonkaen-workshop-learner.pages.dev
- **3-tab** (https://khonkaen-ai-workshop.pages.dev) = เฉพาะ PM / เจ้าของ / วิทยากร
- **เน็ตล่ม** = ใช้ demo (บัญชี demo ฉายจอ) + **prompt PDF / offline pack** + buddy พาไปต่อ
  - ✅ **ส่งแล้ว** (kkai-lab 2026-07-07): `lab-offline-pack.pdf` (A4 5 หน้า ฟอนต์ไทยฝังครบ พิมพ์แจกได้) + `lab-offline-pack.html` (เปิดออฟไลน์ได้) — มี prompt Core 6 อัน + prompt Advanced + เว็บ HTML สำรองตอนเน็ตล่ม + ลิงก์ learner 2-tab เท่านั้น
- **ห้าม rebuild / clear Google Forms ที่มี response แล้ว** (บทเรียน incident clearAllItems)
- Core เป็น browser-only อยู่แล้ว → ถ้าเครื่องผู้เรียนติดตั้งอะไรไม่ได้ ก็ยังทำ Core ครบ

---

## 5. ผลลัพธ์ที่สัญญาได้

**ทุกคน (Core — วัดผลได้):**
1. ใช้ Claude ช่วยงานจริงของตัวเองได้ ≥1 งาน
2. มี landing page 1 หน้าจาก template ที่มีลิงก์จริง เปิดบนมือถือได้
3. เข้าใจภาพรวม DB + GitHub ว่าใช้ต่อยอดอย่างไร

**คนกลุ่มพร้อม (Advanced):**
4. เว็บที่แก้เอง + deploy จริง และ/หรือ ต่อ database / push GitHub ได้จริง

**Demo-only:** หัวข้อที่เสี่ยง/เกินเวลา วิทยากรฉายด้วยบัญชี demo ให้เห็นภาพ ไม่บังคับทำ

---

## 6. ส่งต่อใคร

- **kkai-curriculum** — agenda นาทีต่อนาที: Core (browser-only) เป็นแกนเวลาหลัก · Advanced เป็น stretch block คู่ buddy · Demo-only แทรกสั้นๆ ตอนของเสี่ยง/เกินเวลา
- **kkai-lab** — exercise 2 ระดับ (Core browser-only + Advanced ทำจริง) + **prompt PDF สำหรับ fallback เน็ตล่ม**
- **kkai-slides** — ตัดคำ/ขั้นตอนที่ต้องติดตั้งออกจากส่วน Core
- **kkai-qa** — ตรวจ Core outcome วัดผลได้จริงใน 1 วัน + buddy pairing เป็นไปได้ + fallback ครบ
- **kkai-dayof** — เอา scope 3 ชั้น + fallback ไปทำ runbook

---

*v2 นี้เป็นฉบับ final ตาม master decision 2026-07-07 — ปิด escalation ทั้ง 3 ข้อจาก v1 แล้ว*
