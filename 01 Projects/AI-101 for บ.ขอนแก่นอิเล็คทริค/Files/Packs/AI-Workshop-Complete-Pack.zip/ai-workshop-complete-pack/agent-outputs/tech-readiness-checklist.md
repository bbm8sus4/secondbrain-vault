# Tech Readiness Checklist — AI Workshop ขอนแก่นอิเล็คทริค

วันที่ตรวจ: 2026-07-07  
Role: Tech Setup  
Deadline ใหม่: ต้องปิดงานเตรียมทั้งหมดภายในวันนี้ 2026-07-07

## สรุปสั้น

สถานะรวม: **Tech gate ปิดแล้วหลัง owner override — ไม่ต้องทำ account/pre-task/deploy-login เพิ่ม**

Owner override ล่าสุด:
- ไม่ต้อง login บัญชี Claude สำรอง 2 บัญชีบนเครื่องสอน
- ไม่ต้องส่ง pre-task ให้ผู้เรียนหรือเก็บคำตอบ
- ไม่ต้อง login Cloudflare / GitHub เพื่อโชว์ deploy สด
- ไม่ต้องพิมพ์ handout เป็นชุดกระดาษ
- ไม่ต้องรอคำตอบคุณป๊อบเพื่ออัปเกรด Plan A

Master decision final:
- **Core:** ทุกคน, browser-only, Claude + งานจริง + landing template
- **Advanced:** คนพร้อม + buddy, GitHub + deploy + database ทำจริง
- **Demo-only:** ฉายจอด้วยบัญชี demo สำหรับหัวข้อที่เสี่ยงหรือเกินเวลา

Fallback ที่ล็อกแล้ว:
- **ลิงก์หลักหน้างาน = learner 2-tab เท่านั้น:** `https://khonkaen-workshop-learner.pages.dev`
- 3-tab ใช้เฉพาะ PM / เจ้าของ / วิทยากร
- เน็ตล่ม = demo + prompt PDF + buddy
- ห้าม rebuild / clear Google Forms ที่มี response แล้ว

สิ่งที่พร้อมแล้ว:
- Dashboard Cloudflare ทั้ง 3 ลิงก์ตอบ HTTP 200
- Dashboard gate ปิดแล้ว: source 2-tab ถาวร, Apps Script ล็อก clear/delete, mobile 390x844 ผ่าน
- Lab content gate ปิดแล้ว: browser-only fallback + Prompt/Template Pack พร้อม
- Lab ทำ offline PDF เองแล้ว: `lab-offline-pack.pdf` จึงตัด handout PDF ออกจาก gate ของ tech
- `wrangler` ติดตั้งแล้วแบบ local npm: version 4.107.0
- `gh` ติดตั้งแล้วแบบ local binary: `tools/bin/gh`, version 2.96.0
- Pre-task draft มีอยู่ แต่ owner ตัดออกจากแผนแล้ว ไม่ต้องส่ง
- Google Forms ทั้ง Owner และ Learner เปิดได้ HTTP 200
- มีไฟล์ dashboard/data/forms สำรองใน vault แล้ว
- มีข้อมูลผู้เรียน 11 คนและ owner response ที่กู้คืนแล้ว

จุดเสี่ยงที่อาจทำให้วันสอนพัง:
- ผู้เรียนหลายคนยังไม่มีบัญชี cloud/GitHub/Claude หรือไม่แน่ใจเรื่องสิทธิ์ติดตั้ง → ไม่เป็น blocker เพราะ Core เป็น browser-only
- บัญชี Claude สำรองถูกตัดออกจากแผนแล้ว
- Pre-task ถูกตัดออกจากแผนแล้ว
- `wrangler` และ `gh` ติดตั้งแล้ว แต่ login เป็น optional เฉพาะถ้าจะโชว์ deploy สด Demo-only; ไม่บังคับเพราะ fallback ใช้ live link เดิม
- เคยมี incident ลบคำตอบ Google Forms จากการ rebuild form ด้วย `clearAllItems()` ต้องห้ามทำซ้ำเด็ดขาด
- เป้าหมายเว็บ deploy + database + GitHub ใน 1 วันถูกตัดเป็น Advanced/Demo-only แล้ว แต่ต้องให้เอกสาร Lab/PM ตรงกับ scope นี้

## หลักฐานที่เช็กแล้ว

แหล่งข้อมูล:
- `kkai-agent-system.md`
- `secondbrain-vault/01 Projects/AI Workshop - ขอนแก่นอิเล็คทริค/README.md`
- `01-Forms-Setup.md`
- `05-INCIDENT-ข้อมูลหาย-กู้คืน.md`
- `06-Dashboard-Summary.md`
- `Files/Forms/FORM_URLS.md`
- `Files/Slides/Part1-Claude-Basics.md`
- `Files/Data/`
- `Files/Dashboard/`

ผลตรวจลิงก์:
- `https://khonkaen-ai-workshop.pages.dev` — HTTP 200
- `https://khonkaen-workshop-learner.pages.dev` — HTTP 200
- `https://khonkaen-pricing.pages.dev` — HTTP 200
- Owner Google Form published URL — HTTP 200
- Learner Google Form published URL — HTTP 200

ผลตรวจเครื่องมือใน workspace:
- มี: `git 2.53.0`, `node v22.22.1`, `npm 9.2.0`, `npx 9.2.0`, `python3 3.14.4`
- มีแบบ local: `./node_modules/.bin/wrangler 4.107.0`, `tools/bin/gh 2.96.0`
- ยังไม่ได้ login: `wrangler whoami` บอกให้รัน `wrangler login`; `gh auth status` บอกว่ายังไม่ logged in
- ไม่มีใน PATH: `clasp`

## Checklist ปิดงานวันนี้

### 0. Gate ตาม Master Decision Final

- [x] Tech: install `wrangler` + `gh` บนเครื่องนี้
- [ ] Owner/PM: login Claude สำรอง 2 บัญชีให้พร้อมใช้จริง
- [ ] Owner/PM: ส่ง pre-task ให้ผู้เรียนและรวบรวมคำตอบ laptop/install/GitHub ให้ logistics
- [ ] Optional: login `wrangler` + `gh` บนเครื่องวิทยากรหรือเครื่อง admin ถ้าจะโชว์ deploy สด Demo-only
- [ ] Tech: ทำ offline backup สำหรับ learner link, dashboard, slides, prompts, data
- [x] Tech: เตรียม pre-task message ที่ `pre-task-message-to-learners.md`
- [x] Dashboard: ย้าย source 2-tab ออกจาก `/tmp`
- [x] Dashboard: ล็อก Apps Script จุด `clearAllItems` / delete ไม่ให้รันกับฟอร์มที่มี response
- [x] Dashboard: เช็ก mobile learner 2-tab แล้ว 390x844 ผ่าน
- [x] Lab: ทำ browser-only fallback + Prompt/Template Pack
- [x] Lab: export offline pack PDF เองแล้ว (`lab-offline-pack.pdf`) — ไม่ใช่ gate tech แล้ว
- [ ] PM: รวม checklist ทั้งหมดตาม scope 3 ชั้น

### 1. บัญชีผู้เรียนและบัญชีสอน

- [ ] ยืนยันบัญชี Claude ที่จะใช้สอน: ใครจ่าย, ใช้แผนไหน, แชร์กี่คนต่อบัญชี
- [ ] เตรียมบัญชี Claude สำรองอย่างน้อย 2 บัญชี สำหรับคน login ไม่ได้หรือ rate limit
- [ ] ยืนยันว่าผู้เรียนทุกคนมีอีเมลที่ login ได้จริงในวันสอน
- [ ] ยืนยันว่าผู้เรียนที่ต้องทำเว็บมี GitHub account หรือมี fallback เป็นบัญชีกลาง/คู่ buddy
- [ ] ยืนยันบัญชี Cloudflare/Vercel/Netlify ที่ใช้ demo deploy แล้ว login ค้างบนเครื่องวิทยากร
- [ ] ยืนยันบัญชี Google `bobbysomporn@gmail.com` ที่ถือ Forms/Apps Script ยังเข้าได้ และเปิด 2FA/recovery พร้อม
- [ ] ห้ามให้ผู้เรียนทุกคนสร้างบัญชีพร้อมกันหน้างานโดยไม่มีแผนสำรอง เพราะอาจติด SMS/2FA/rate limit

### 2. เครื่องมือบนเครื่องวิทยากร

- [x] ติดตั้งและทดสอบ version ของ `wrangler` บนเครื่องนี้
- [x] ติดตั้งและทดสอบ version ของ `gh` บนเครื่องนี้
- [ ] Optional: Login `wrangler` ด้วย Cloudflare account ที่ใช้ deploy จริง ถ้าจะ demo deploy สด
- [ ] Optional: Login `gh` ด้วย GitHub account ที่ใช้ demo/Advanced จริง ถ้าจะ demo push/deploy สด
- [ ] ติดตั้งและทดสอบ `clasp` เฉพาะเครื่อง admin เท่านั้น ไม่ใช้กับเครื่องผู้เรียน
- [ ] ทดสอบ `node`, `npm`, `git`, browser, screen sharing, projector resolution
- [ ] เปิด dashboard, Forms, Claude, GitHub, deploy provider ใน browser profile เดียวกันก่อนวันสอน
- [ ] เตรียม browser สำรอง: Chrome และ Edge/Firefox
- [ ] เตรียม hotspot/มือถืออย่างน้อย 2 เครื่อง สำหรับกรณี Wi-Fi ห้องล่ม

### 3. Dashboard และลิงก์แชร์

- [x] Dashboard 3-tab เปิดได้: `https://khonkaen-ai-workshop.pages.dev`
- [x] Dashboard learner-only เปิดได้: `https://khonkaen-workshop-learner.pages.dev`
- [x] Pricing calculator เปิดได้: `https://khonkaen-pricing.pages.dev`
- [x] ระบุชัดว่าลิงก์หลักหน้างาน/ผู้เรียนคือ learner-only 2-tab
- [x] ระบุชัดว่า 3-tab ใช้เฉพาะ PM / เจ้าของ / วิทยากร
- [ ] เปิดตรวจ learner 2-tab จากมือถือจริงอีกครั้งก่อนส่งลิงก์
- [ ] เก็บ QR code ของลิงก์สำคัญเป็น PNG/PDF สำหรับเปิด offline หรือฉายบนจอ
- [ ] ทำสำเนา `AI-Workshop-รวม.html` เป็น `index.html` ในโฟลเดอร์ backup ถาวร ไม่พึ่ง `/tmp`

### 4. Google Forms และข้อมูลสำรวจ

- [x] Owner Form published URL เปิดได้
- [x] Learner Form published URL เปิดได้
- [ ] ยืนยันใน Google Forms UI ว่า response destination ถูกผูกกับชีตที่ถูกต้อง
- [ ] Export response ล่าสุดเป็น CSV/XLSX วันนี้ หลังปิดรับคำตอบ
- [ ] เก็บ backup ไว้ 3 ที่: vault, เครื่องวิทยากร, cloud drive
- [ ] ลบหรือ rename duplicate forms เพื่อกันส่งลิงก์ผิด
- [ ] ห้าม rebuild ฟอร์มที่มี response แล้ว
- [ ] ถ้าต้องแก้ฟอร์ม ให้แก้ in-place เท่านั้น เช่น `setTitle`, `setChoiceValues`, หรือ `addItem` ต่อท้าย

### 5. Offline backup

- [ ] เปิด local file ได้โดยไม่ใช้อินเทอร์เน็ต:
  - `Files/Dashboard/AI-Workshop-รวม.html`
  - `Files/Dashboard/Dashboard.html`
  - `Files/Costs/Pricing-Calculator.html`
  - `Files/Slides/Part1-Claude-Basics.md`
  - `Files/Data/learner_recovered.csv`
  - `Files/Data/owner_recovered.csv`
  - `Files/Data/RECOVERED_responses.xlsx`
- [ ] Export slides เป็น PDF เพราะ Marp/Markdown อาจเปิดไม่เหมือนกันทุกเครื่อง
- [ ] Export dashboard เป็น PDF screenshots อย่างน้อย 3 หน้า: owner, learner, alignment
- [ ] เตรียม zip รวมไฟล์ workshop ทั้งหมดไว้ใน USB หรือ cloud drive ที่เปิดจากมือถือได้
- [x] Prompt/offline PDF ถูกปิดโดย lab แล้ว (`lab-offline-pack.pdf`)

### 6. Pre-task สำหรับผู้เรียน

- [ ] ส่ง pre-task วันนี้ ไม่เกิน 30 นาที:
  - เปิด `claude.ai` และ login
  - เปิด GitHub หรือสร้าง account เฉพาะคนที่จะเข้ากลุ่ม Advanced
  - เช็กว่าเครื่องติดตั้งโปรแกรมได้หรือไม่
  - เปิด dashboard learner-only 2-tab จากมือถือและคอม
  - ตอบว่ามีข้อจำกัด: ไม่มีโน้ตบุ๊ก, ติด 2FA, ติดตั้งไม่ได้, ใช้เน็ตบริษัทไม่ได้
- [x] เตรียมข้อความ pre-task พร้อมส่ง: `pre-task-message-to-learners.md`
- [ ] แบ่งกลุ่มจากผล pre-task:
  - Core: ทุกคน, browser-only, Claude + งานจริง + landing template
  - Advanced: คนพร้อม + buddy, GitHub + deploy + database ทำจริง
  - Demo-only: ฉายจอด้วยบัญชี demo สำหรับหัวข้อที่เสี่ยงหรือเกินเวลา
- [ ] เตรียมรายชื่อ buddy โดยดึงคนพร้อมสูง เช่น เบนซ์/ต่อ/นัท ช่วยกลุ่มเริ่มต้น

## Risk Register

### R1: Login Claude/GitHub/Cloud ล่มหรือสร้างบัญชีไม่ทัน

ความรุนแรง: สูง  
ผลกระทบ: hands-on หยุดทั้งห้อง

วิธีแก้ทันที:
- ใช้บัญชี demo ของวิทยากรฉายจอ
- ให้ผู้เรียนทำตามในเอกสาร prompt/PDF ก่อน
- จับคู่กับคนที่ login ได้
- ถ้า deploy/database เสี่ยงเกินเวลา ให้ย้ายเป็น Demo-only ทันที

วิธีป้องกันวันนี้:
- ส่ง pre-task login
- เตรียมบัญชีสำรอง
- เตรียม fallback แบบไม่ต้อง deploy

### R2: ผู้เรียนไม่มีสิทธิ์ติดตั้งโปรแกรม

ความรุนแรง: สูง  
หลักฐาน: survey ระบุว่าหลายคนไม่แน่ใจหรือต้องให้ IT/วิทยากรติดตั้ง

วิธีแก้ทันที:
- ใช้ browser-only workflow
- ใช้ StackBlitz/CodeSandbox/GitHub web editor ถ้าจำเป็น
- ตัด CLI เป็น demo-only สำหรับกลุ่ม Core

วิธีป้องกันวันนี้:
- ให้ IT ยืนยันสิทธิ์เครื่อง
- เตรียมเครื่องกลาง 1-2 เครื่อง

### R3: Google Forms response เสียจากการแก้ฟอร์ม

ความรุนแรง: วิกฤต  
หลักฐาน: เคยเกิด incident 2026-06-30 และกู้คืนด้วย Forms REST API

วิธีแก้ทันที:
- หยุดแก้ฟอร์ม
- Export raw responses ก่อน
- ใช้ recovery protocol จาก `05-INCIDENT-ข้อมูลหาย-กู้คืน.md`

วิธีป้องกันวันนี้:
- ห้าม `clearAllItems()` / `deleteItem()` กับฟอร์มที่มี response
- แก้เฉพาะ in-place
- backup CSV/XLSX ก่อนแตะฟอร์มทุกครั้ง

### R4: Dashboard deploy แก้สดไม่ได้

ความรุนแรง: กลางถึงสูง  
หลักฐาน: `wrangler` ติดตั้งแล้วแบบ local แต่ยังไม่ได้ login; ถ้าไม่มี Cloudflare credential จะ redeploy สดไม่ได้

วิธีแก้ทันที:
- ใช้ Cloudflare Pages link เดิมที่ยังเปิดได้
- เปิด local HTML จาก vault แทน
- ฉาย PDF/screenshots หากอินเทอร์เน็ตล่ม

วิธีป้องกันวันนี้:
- ถ้าจะโชว์ deploy สด Demo-only ให้ login `wrangler` บนเครื่องวิทยากร
- ถ้าไม่ login ให้ใช้ live link เดิม + local backup ตาม fallback
- เก็บ deploy folder ถาวร ไม่ใช่ `/tmp`
- Export screenshots/PDF

### R5: เนื้อหาสายเทคนิคหนักเกิน 1 วัน

ความรุนแรง: สูง  
หลักฐาน: ความพร้อมจริง GitHub 0.8/3, database 0.9/3, 7/11 กังวลเรียนไม่ทัน, 6/11 ไม่เคยเขียนโค้ด

วิธีแก้ทันที:
- Core ทุกคนจบที่ใช้ Claude กับงานจริงและ landing page แบบ template
- Advanced ทำ GitHub/deploy/database เฉพาะคนพร้อม
- Database และ GitHub สำหรับกลุ่ม Core เป็น demo-only

วิธีป้องกันวันนี้:
- ใช้ Master decision final เป็นขอบเขตเดียวกันทุกทีม
- ส่ง agenda ที่ระบุ Core/Advanced ชัด

## ลิงก์และไฟล์สำคัญ

Dashboard:
- หน้างาน/ผู้เรียนหลัก: `https://khonkaen-workshop-learner.pages.dev`
- PM / เจ้าของ / วิทยากร: `https://khonkaen-ai-workshop.pages.dev`
- Pricing Calculator: `https://khonkaen-pricing.pages.dev`

Forms:
- Owner Form: `https://docs.google.com/forms/d/e/1FAIpQLSd5MbOlD6K34VBNTGPXq0PMEDd1mYKzpkEp0pi48YcMy9qRBQ/viewform`
- Learner Form: `https://docs.google.com/forms/d/e/1FAIpQLSeBCuLJ6zUNICcylKvQTfng_lrnSPt10BhYijD-76ow9MJfTw/viewform`
- Apps Script editor: `https://script.google.com/d/1r5GYtrTrwvdmfF6EKlbmg-9iHT-zVC_rg2yqo-e7u0pj_8Xk3aRitrsc/edit`

Local backup:
- `secondbrain-vault/01 Projects/AI Workshop - ขอนแก่นอิเล็คทริค/Files/Dashboard/`
- `secondbrain-vault/01 Projects/AI Workshop - ขอนแก่นอิเล็คทริค/Files/Data/`
- `secondbrain-vault/01 Projects/AI Workshop - ขอนแก่นอิเล็คทริค/Files/Forms/`
- `secondbrain-vault/01 Projects/AI Workshop - ขอนแก่นอิเล็คทริค/Files/Slides/`

## สถานะตอนนี้

พร้อมใช้:
- ลิงก์ dashboard/form หลักเปิดได้
- ไฟล์ backup หลักอยู่ใน vault
- Dashboard gate ปิดแล้ว
- Lab content gate ปิดแล้ว
- สไลด์ Part 1 มีแล้ว

ต้องปิดวันนี้:
- Owner/PM login บัญชี Claude สำรอง 2 บัญชีให้พร้อมใช้จริง
- Owner/PM ส่งและเก็บผล pre-task ผู้เรียน
- ส่งผล pre-task เรื่อง laptop/install/GitHub ให้ logistics
- Export offline backup เป็น PDF/CSV/XLSX/zip
- ยืนยันบัญชี Claude/GitHub/cloud และแผนสำรอง
- Optional: login `wrangler` + `gh` ถ้าจะโชว์ deploy สด Demo-only
- ให้ทุก deliverable ใช้ scope 3 ชั้นเดียวกัน

Owner ถัดไป:
- kkai-pm/คุณป๊อบ: จัดหาและ login บัญชี Claude สำรอง 2 ชุด
- kkai-pm/คุณป๊อบ: ส่ง pre-task ให้ผู้เรียนผ่านช่องทางจริง
- kkai-logistics: รับคำตอบ pre-task เรื่อง laptop/install/GitHub
- kkai-tech-setup: offline backup และ support ถ้า owner ต้องการ login `wrangler`/`gh` สำหรับ demo สด
- kkai-dashboard: complete
- kkai-lab: content complete
