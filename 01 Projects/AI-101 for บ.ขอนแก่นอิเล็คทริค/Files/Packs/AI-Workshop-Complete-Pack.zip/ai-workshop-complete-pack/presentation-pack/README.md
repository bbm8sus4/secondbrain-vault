# AI Workshop Presentation Pack

ชุดไฟล์สำหรับนำเสนอ AI Workshop — บ.ขอนแก่นอิเล็คทริค

## เปิดสอนจริง

1. `slides/01-Part1-Claude-Basics.pdf`
2. `slides/02-Part2-AI-Marketing.pdf`
3. `slides/03-Part3-Landing-Page-NoCode.pdf`
4. `slides/04-Part4-Cowork-ClaudeCode-Warp.pdf`

## Dashboard

- ใช้หน้างาน/ผู้เรียน: `dashboard/AI-Workshop-learner-2tab.html`
- ใช้เฉพาะ PM/เจ้าของ/วิทยากร: `dashboard/AI-Workshop-full-3tab.html`

Live links:
- Learner: https://khonkaen-workshop-learner.pages.dev
- Full: https://khonkaen-ai-workshop.pages.dev

## Handouts

- `handouts/kkai-lab-handout-full.pdf`
- `handouts/kkai-prompt-template-pack.pdf`
- `handouts/lab-offline-pack.html`

## Runbook

- `runbook/agenda-minute-by-minute.md`
- `runbook/dayof-runbook.md`

## Notes

- Core = browser-only
- Advanced = optional / demo as needed
- Do not rebuild or clear Google Forms with existing responses
