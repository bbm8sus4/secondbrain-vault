#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

const dir = __dirname;
const sourcePath = path.join(dir, 'AI-Workshop-รวม.html');
const outputPath = path.join(dir, 'AI-Workshop-learner.html');

let html = fs.readFileSync(sourcePath, 'utf8');

html = html.replace(
  /<p class="sub">รวมมุมเจ้าของธุรกิจ \(ความคาดหวัง\) และมุมผู้เข้าอบรม \(ผลสำรวจ\) ไว้ที่เดียว · เลือกดูทีละมุม<\/p>/,
  '<p class="sub">สรุปผลสำรวจผู้เข้าอบรม 11 คน<wbr> · เทียบความสอดคล้องกับความคาดหวังเจ้าของธุรกิจ</p>'
);

html = html.replace(
  /<button class="tabbtn active" type="button" data-tab="owner">ความคาดหวังเจ้าของธุรกิจ<\/button>\s*<button class="tabbtn" type="button" data-tab="learner">สรุปผู้เข้าอบรม<\/button>/,
  '<button class="tabbtn active" type="button" data-tab="learner">สรุปผู้เข้าอบรม</button>'
);

html = html.replace(
  /<div class="tab active" id="tab-owner">[\s\S]*?(?=\n  <div class="tab" id="tab-learner">)/,
  ''
);

html = html.replace(
  '<div class="tab" id="tab-learner">',
  '<div class="tab active" id="tab-learner">'
);

html = html.replace(
  '<h1>บ.ขอนแก่นอิเล็คทริค — สรุป AI Workshop</h1>',
  '<h1><span class="hb-main">บ.ขอนแก่นอิเล็คทริค</span> <span class="hb-dash">—</span> <span class="hb-tail">สรุป AI Workshop</span></h1>'
);

html = html.replace(
  'body{margin:0;background:var(--bg);color:var(--ink);font-family:"IBM Plex Sans","IBM Plex Sans Thai",-apple-system,BlinkMacSystemFont,sans-serif;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;font-kerning:normal;line-height:1.5}',
  'html,body{overflow-x:hidden;max-width:100%}\n  body{margin:0;background:var(--bg);color:var(--ink);font-family:"IBM Plex Sans Thai","IBM Plex Sans",-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;font-kerning:normal;font-feature-settings:"kern","liga","calt";text-rendering:optimizeLegibility;line-height:1.55;letter-spacing:0;word-break:normal;overflow-wrap:normal;line-break:strict}'
);

const mobileCss = `
  @media(max-width:620px){
    .hero-inner{padding:34px 16px 22px}
    h1{font-size:28px;line-height:1.18;letter-spacing:0}
    .hb-main{display:block}
    .hb-dash{display:none}
    .hb-tail{display:block;color:#d7ddf6;font-weight:500}
    .kpi{grid-template-columns:repeat(2,1fr);gap:10px;margin-top:22px}
    .k{min-height:94px;padding:13px 14px}
    .k .n{font-size:22px;letter-spacing:0}
    .k .l{font-size:11px}
    .wrap{padding:0 14px 42px}
    .tabbar{gap:8px}
    .tabbtn{font-size:13px;padding:8px 12px}
    .rrow{grid-template-columns:26px minmax(0,1fr) 66px 30px;gap:8px}
    .rnm{font-size:12.5px}
    .rbar{min-width:0}
    .exwrap{min-height:300px}
    .acc-head{padding:14px 15px}
    .acc-head .t{font-size:14px;line-height:1.35}
    .acc-grid{grid-template-columns:1fr}
    .qcard{padding:13px 14px}
    .pm-ov{padding:10px}
    .pm{max-height:92vh;border-radius:14px}
    .pm-head{padding:16px}
    .pm-body{padding:4px 16px 18px}
    footer{font-size:12px;margin-top:26px}
    .sec-head{align-items:flex-start;gap:8px}
    .sec-head .tools{margin-left:0;width:100%;order:99;margin-top:4px;justify-content:flex-start}
    .sec-head .tbtn{flex:1;text-align:center;padding:8px 10px;font-size:12px}
    .tools{flex-wrap:wrap}
    .card,.acc,.qcard{min-width:0;max-width:100%}
    .ownwhy{padding:12px 14px;font-size:13px;line-height:1.6;overflow-wrap:break-word;word-break:normal}
  }
`;

html = html.replace('</style>', `${mobileCss}\n</style>`);

html = html.replace(
  /@media\(max-width:760px\)\{\.cmp,\.cmp thead,\.cmp tbody,\.cmp tr,\.cmp td\{display:block\}\.cmp thead\{display:none\}\.cmp tr\{border-top:1px solid var\(--line\);padding:6px 0\}\.cmp td\{border-top:0;padding:5px 16px\}\.cmp td\.dim\{padding-top:13px;font-size:15px\}\}/,
  '@media(max-width:760px){.cmp,.cmp thead,.cmp tbody,.cmp tr,.cmp td{display:block;width:auto}.cmp thead{display:none}.cmp{border:1px solid var(--line);border-radius:14px;overflow:hidden;background:#fff}.cmp tr{border-top:1px solid var(--line);padding:14px 16px 16px;background:#fff}.cmp tr:first-child{border-top:0}.cmp td{border-top:0;padding:4px 0;font-size:14px;line-height:1.55;word-break:normal;overflow-wrap:normal}.cmp td.dim{width:auto!important;padding:0 0 6px;font-size:15px;font-weight:700;color:var(--ink);letter-spacing:0}.cmp td:nth-child(2){color:var(--muted);font-size:13px}.cmp td:nth-child(2)::before{content:"เจ้าของคาดหวัง · ";color:#9aa0b6;font-weight:600;font-size:11px;letter-spacing:.3px;text-transform:uppercase;display:block;margin-top:4px;margin-bottom:2px}.cmp td:nth-child(3)::before{content:"ผู้เรียนจริง";color:#9aa0b6;font-weight:600;font-size:11px;letter-spacing:.3px;text-transform:uppercase;display:block;margin-top:8px;margin-bottom:2px}.cmp td:nth-child(4){padding-top:10px}.cmp .sm{display:inline-block;margin-top:4px;font-size:12.5px}}'
);

html = html.replace(
  "if(location.hash.indexOf('align')>=0) showTab('align');\n  else if(/learner|all|p=/.test(location.hash)) showTab('learner');",
  "if(location.hash.indexOf('align')>=0) showTab('align'); else { showTab('learner'); }"
);

if (html.includes('id="tab-owner"')) {
  throw new Error('Owner tab still present after learner build.');
}

fs.writeFileSync(outputPath, html);
console.log(outputPath);
